program TabbedBrowser2;

{$mode objfpc}{$H+}

uses
  {$IFDEF UNIX}
  cthreads,
  {$ENDIF}
  {$IFDEF HASAMIGA}
  athreads,
  {$ENDIF}
  Interfaces, // this includes the LCL widgetset
  Forms,
  uCEFApplication,
  uMainForm in 'uMainForm.pas' {MainForm},
  uBrowserFrame in 'uBrowserFrame.pas' {BrowserFrame: TFrame},
  uBrowserTab in 'uBrowserTab.pas';

{.$R *.res}

begin
  CreateGlobalCEFApp;

  if StartMainProcess then
    begin
      // The LCL Widgetset must be initialized after the CEF initialization and
      // only in the browser process.
      CustomWidgetSetInitialization;

      RequireDerivedFormResource:=True;
      {$PUSH}{$WARN 5044 OFF}
      Application.MainFormOnTaskbar:=True;
      {$POP}
      Application.Initialize;
      Application.CreateForm(TMainForm, MainForm);
      Application.Run;

      CustomWidgetSetFinalization;
    end;

  DestroyGlobalCEFApp;
end.
